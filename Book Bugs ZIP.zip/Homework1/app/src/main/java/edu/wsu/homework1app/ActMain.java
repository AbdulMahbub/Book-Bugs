//====================================================================
// Name: Abdul Mahbub
// Application: Book Bugs
// Activity:    ActMain
// Description:
//   This Android application shows a small menu for selecting books and displays outputs in a toast message
//
//====================================================================

package edu.wsu.homework1app;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ActMain extends AppCompatActivity {
    public static final String APP_NAME = "Homework1";

    // For copying text
    private EditText txtBookName;
    private EditText txtCost;
    private EditText txtTax;
    private EditText txtTotal;
    private EditText customerName;
    private EditText email;
    private RadioGroup radio;
    private RadioButton radioButton;




    // Arrays for books and their corresponding prices
    final String[] bookNames = {"Of Mice and Men", "The Fourth Stall", "Fahrenheit 451","The Giver",
            "The Road","The Very Hungry Caterpillar","To Kill A Mockingbird","The Shining"};

    final double[] bookPrices={9.58, 6.99, 8.29, 5.90, 10.50, 5.06, 6.50, 6.70 };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.laymain);

        txtBookName = findViewById(R.id.txtBookName);
        txtCost= findViewById(R.id.txtCost);
        txtTax= findViewById(R.id.txtTax);
        txtTotal= findViewById(R.id.txtTotal);
        customerName= findViewById(R.id.customerName);
        email= findViewById(R.id.email);
        radio = (RadioGroup) findViewById(R.id.radio);
    }

    // Combine the arrays and throw it into my listDialog box
    public String[] combineArrays(String[] names, double prices[])
    {
        String ans[]=new String[names.length];
        for(int i=0;i<ans.length;i++) {
            double temp=prices[i];
            temp=Math.round(temp*100.0)/100.0;

            ans[i]=names[i]+", $" + temp;
        }

        return ans;
    }

    public void showListDialogBox(View v)
    {
        String ans[]=combineArrays(bookNames,bookPrices);

        AlertDialog.Builder builder =
                new AlertDialog.Builder(v.getContext());
        builder.setTitle("Select a book from below:");
        builder.setItems(ans,
                new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog,
                                        int option)
                    {
                        // Functions for the read only boxes
                        showBookTitle(v, bookNames[option]);
                        showPrice(v, bookPrices[option]);
                        showSalesTax(v, bookPrices[option]);
                        showTotalCost(v, bookPrices[option]);

                        Toast.makeText(getApplicationContext(),
                                '"'+bookNames[option] +'"'+ " has been selected.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
        builder.show();
    }

    // this function retrieves the book title from dialog box
    public void showBookTitle(View v,String name)
    {
       txtBookName.setText(name);
    }

    // this function retrieves the book title from dialog box
    public void showPrice(View v,double price)
    {
        txtCost.setText("$"+price+"");
    }

    public void showSalesTax(View v,double price)
    {
        double tax=price*0.06;
        tax=Math.round(tax*100.0)/100.0;
        txtTax.setText("$"+tax+"");
    }

    public void showTotalCost(View v, double price)
    {
        double total= price+ (price*0.06);
        total=Math.round(total*100.0)/100.0;
        txtTotal.setText("$"+total+"");
    }

    public void submitButton(View v) {

        // To catch if info isn't given
        if (txtBookName.getText().toString().isEmpty())
        {
            Toast.makeText(getApplicationContext(), "Book must be selected", Toast.LENGTH_LONG).show();
            return;
        }

        if (customerName.getText().toString().isEmpty())
        {
            Toast.makeText(getApplicationContext(), "Name must be entered", Toast.LENGTH_SHORT).show();
            return;
        }

        if (email.getText().toString().isEmpty())
        {
            Toast.makeText(getApplicationContext(), "Email must be entered", Toast.LENGTH_SHORT).show();
            return;
        }

        // Button that displays the toast message
        String message="";
        message+=txtBookName.getText().toString()+"\n";
        message+="Name: "+customerName.getText().toString()+"\n";
        message+="EMAIL: "+email.getText().toString()+"\n";
        message+="Cost: "+txtCost.getText().toString()+"\n";
        message+="Tax: "+txtTax.getText().toString()+"\n";
        message+="Total: "+txtTotal.getText().toString()+"\n";

        // Get id from checked radio button then use id to retrieve text
        int selectedId = radio.getCheckedRadioButtonId();
        radioButton = (RadioButton) findViewById(selectedId);


        message+="Payment Type: "+radioButton.getText().toString();

        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();

    }

    public void resetButton(View v)
    {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(v.getContext());
        builder.setTitle(APP_NAME + " Message");
        builder.setMessage("Are you sure you wanna reset the screen?");
        builder.setPositiveButton("No",
                new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int option)
                    {
                      return;
                    }
                });
        builder.setNegativeButton("Yes",
                new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int option)
                    {
                        // Resets all text fields to blanks
                        txtBookName.setText("");
                        customerName.setText("");
                        email.setText("");
                        txtCost.setText("");
                        txtTax.setText("");
                        txtTotal.setText("");

                        // Reset radio buttons
                        radio.clearCheck();
                    }
                });
        builder.show();

    }



}